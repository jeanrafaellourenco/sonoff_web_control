sonoff_off

sonoff_on


https://maker.ifttt.com/trigger/sonoff_off/with/key/d1yT0zkH_U5QT2iL3Tq5kf4994nJLnYjTD_yK9Zt1Vt


https://maker.ifttt.com/trigger/sonoff_on/with/key/d1yT0zkH_U5QT2iL3Tq5kf4994nJLnYjTD_yK9Zt1Vt